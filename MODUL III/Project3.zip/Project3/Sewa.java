package Project3;

public class Sewa { 
    String judul; //Atribut
    String publisher;
    int stok;
    
     Sewa(String judul,String publisher, int stok){
        this.judul = judul; //Mengambil Atribut secara Khusus
        this.publisher = publisher;
        this.stok = stok;
    }
    Sewa(){ //Return 
        
    }
}
