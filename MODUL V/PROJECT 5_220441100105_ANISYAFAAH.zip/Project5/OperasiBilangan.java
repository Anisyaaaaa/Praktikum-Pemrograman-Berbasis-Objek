package Project5;

public class OperasiBilangan {
    protected double a, b, c, d;
    
    protected void set_A(double a){
        this.a = a;
    }
    protected void set_B(double b){
        this.b = b;
    }   
    protected void set_C(double c){
        this.c = c;
    }
    protected void set_D(){
    }
    
    protected double get_A(){
        return this.a;
    }
    protected double get_B(){
        return this.b;
    }
    protected double get_C(){
        return this.c;
    }
    protected double get_D(){
        return this.d;
    }
    protected void tampil(){
    }
}