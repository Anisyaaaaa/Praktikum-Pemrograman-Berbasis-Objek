abstract class Menu {
    abstract void showMenu();
}