public interface Ticketable {
    void bookTicket(String movieTitle, String seatNumber, int ticketCount, double ticketPrice);
}